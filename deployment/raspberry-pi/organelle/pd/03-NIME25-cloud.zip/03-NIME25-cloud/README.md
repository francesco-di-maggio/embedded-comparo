This is a live sampling cloud generator using a circular double buffer input. 

It is inspired by Cipriani & Giri's Vol. 3 gen~ example and double buffer example adapted by  Fracesco Di Maggio. 

I used our old port of Sakonda's linear MSP granulator as the basis to respond to cloud generation messages. 

It uses the PD object, clone.



Atau Tanaka August 2024 London